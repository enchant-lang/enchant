// priv/lib/js/leaves.mjs — the host leaves: the BEAM primitives Beam Lisp's own
// source calls, implemented once for JavaScript (PLAN-163 U1).
//
// The compiler's own namespaces (reader, compiler, core, rt …) are Beam Lisp,
// but at the bottom they call BEAM primitives: `erlang/element`, `lists/split`,
// `string/to_integer`, `unicode/characters_to_list` … A namespace compiled to
// JS links each such call to `LEAVES["mod/fun/arity"]` here, at BUILD time
// (priv/lib/js/build.bl); a call with no entry is a build error that names it.
//
// Each leaf has the BEAM function's semantics on the JS value model (rt.mjs):
//
//   Erlang list    a BL list (Cons … EMPTY). A "charlist" is a list of
//                  codepoint integers, as on the BEAM.
//   Erlang tuple   Tup. `{:ok, v}` is `tup([kw("ok"), v])`.
//   atom           Kw (a BL keyword IS an atom on the BEAM).
//   binary         a JS string (only UTF-8 text binaries reach these leaves).
//   map            HMap.
//
// A leaf is small and obviously right, or it is not a leaf: logic belongs in
// Beam Lisp, compiled here from the same source the BEAM runs.

import * as R from "./rt.mjs";
import * as J from "./interop.mjs";
import * as A from "./abi.mjs";
import * as C from "./actor/module.mjs";
import { exactCandidates, ENV } from "./env.mjs";
import { LAZY_LEAVES, cell, LazySeq, Delay, SeqCursor } from "./lazy.mjs";
import { HOST_LEAVES, bindTable, registerModule, resolveRemote, mangle } from "./host-leaves.mjs";
import { LINKS, RETURN_CONSTRUCTOR_SHAPES } from "./core-links.mjs";
const { EMPTY, Cons, Tup, Kw, HMap, Vec, BLError } = R;

const OK = R.kw("ok"), ERROR = R.kw("error");
const T = (...xs) => new Tup(xs);
const isList = (x) => x === EMPTY || x instanceof Cons;
const arr = (l) => { const a = []; for (let p = l; p instanceof Cons; p = p.t) a.push(p.h); return a; };
const list = (a) => R.listFromArray(a);
const atomName = (a) => (a instanceof Kw ? a.fq : String(a));
const badarg = (what, x) => { throw new BLError("errors were found at the given arguments: " + what + " " + R.printStr(x)); };

// ─── charlists ↔ strings ───────────────────────────────────────────────────

function cpsToString(cps) {
  // a "chardata" list: codepoints, nested lists, or binaries (strings)
  let s = "";
  const walk = (l) => {
    for (let p = l; p instanceof Cons; p = p.t) {
      const h = p.h;
      if (typeof h === "number") s += String.fromCodePoint(h);
      else if (typeof h === "string") s += h;
      else if (isList(h)) walk(h);
      else badarg("chardata", h);
    }
  };
  if (typeof cps === "string") return cps;
  walk(cps);
  return s;
}
function stringToCps(s) {
  const a = [];
  for (const ch of s) a.push(ch.codePointAt(0));
  return list(a);
}

// ─── string:to_integer / to_float on a charlist ────────────────────────────
// {Int, Rest} or {error, no_integer}: the LONGEST valid prefix is consumed,
// exactly as Erlang does (a leading sign is part of the number).

function toInteger(cs) {
  const a = arr(cs);
  let i = 0;
  if (a[i] === 43 || a[i] === 45) i++;
  const d0 = i;
  while (i < a.length && a[i] >= 48 && a[i] <= 57) i++;
  if (i === d0) return T(ERROR, R.kw("no_integer"));
  const text = String.fromCodePoint(...a.slice(0, i));
  const n = BigInt(text);
  return T(normInt(n), list(a.slice(i)));
}
function normInt(n) { return (n >= BigInt(Number.MIN_SAFE_INTEGER) && n <= BigInt(Number.MAX_SAFE_INTEGER)) ? Number(n) : n; }

function toFloat(cs) {
  // Erlang requires digits '.' digits, optional exponent; no float → no_float
  const a = arr(cs);
  const s = String.fromCodePoint(...a);
  const m = /^[+-]?\d+\.\d+(?:[eE][+-]?\d+)?/.exec(s);
  if (!m) return T(ERROR, R.kw("no_float"));
  const rest = [...s.slice(m[0].length)].map((c) => c.codePointAt(0));
  return T(R.flt(parseFloat(m[0])), list(rest));
}

// ─── the table ─────────────────────────────────────────────────────────────

export const LEAVES = {
  // erlang
  "erlang/element/2": (i, t) => (t instanceof Tup && i >= 1 && i <= t.items.length ? t.items[i - 1] : badarg("element", t)),
  "erlang/tuple_size/1": (t) => (t instanceof Tup ? t.items.length : badarg("tuple_size", t)),
  "erlang/is_tuple/1": (x) => x instanceof Tup,
  "erlang/is_list/1": (x) => isList(x),
  "erlang/not/1": (x) => x === true ? false : x === false ? true : badarg("not", x),
  "erlang/is_atom/1": (x) => x instanceof Kw || x === true || x === false || x === null,
  "erlang/list_to_tuple/1": (l) => new Tup(arr(l)),
  "erlang/tuple_to_list/1": (t) => list(t.items),
  "erlang/hd/1": (l) => (l instanceof Cons ? l.h : badarg("hd", l)),
  "erlang/tl/1": (l) => (l instanceof Cons ? l.t : badarg("tl", l)),
  "erlang/binary_to_atom/1": (s) => R.kw(s),
  "erlang/atom_to_binary/1": (a) => (a === null ? "nil" : a === true ? "true" : a === false ? "false" : atomName(a)),
  "erlang/binary_to_list/1": (s) => {
    // BYTES of the UTF-8 binary, as on the BEAM
    const b = new TextEncoder().encode(s); return list(Array.from(b));
  },
  "erlang/byte_size/1": (s) => new TextEncoder().encode(s).length,
  "erlang/binary_part/3": (s, start, len) => lateModule("js.binary").d_part(s, start, len),
  // Algorithms live in BL; these are only canonical leaf dispatch adapters.
  "binary/at/2": (s, offset) => lateModule("js.binary").d_at(s, offset),
  "binary/part/3": (s, start, len) => lateModule("js.binary").d_part(s, start, len),
  "binary/match/2": (s, pattern) => lateModule("js.binary").d_match(s, pattern),
  "binary/matches/2": (s, pattern) => lateModule("js.binary").d_matches(s, pattern),
  "erlang/map_size/1": (m) => m.cnt,
  "erlang/trunc/1": (x) => (x instanceof R.Flt ? Math.trunc(x.v) : x),
  "erlang/length/1": (l) => arr(l).length,

  // lists
  // ONE exact reverse. `/1` is `/2` with the empty tail; either arity takes a
  // proper first list, shares (never forces) its tail, and raises R.reverseI's
  // badarg — the intrinsic and the leaf are the same helper by construction.
  "lists/reverse/1": (l) => R.reverseI(l),
  "lists/reverse/2": (l, t) => R.reverseI(l, t),
  // `b` is shared as the tail, as on the BEAM
  "lists/append/2": (a, b) => { const xs = arr(a); let r = b; for (let i = xs.length - 1; i >= 0; i--) r = new Cons(xs[i], r); return r; },
  "lists/last/1": (l) => { const a = arr(l); if (!a.length) badarg("last", l); return a[a.length - 1]; },
  "lists/member/2": (x, l) => arr(l).some((y) => R.keyEq(x, y)),
  // The SECOND half of a split is the original list's own tail, never a copy:
  // BEAM shares it, and the reader walks a cursor until it is `identical?` to
  // that tail (reader/advance-to) — a copy makes every token walk to the end
  // of the source, O(n²) over a file. Only the prefix is rebuilt.
  "lists/split/2": (n, l) => {
    const pre = []; let p = l;
    for (let i = 0; i < n; i++) { if (!(p instanceof Cons)) badarg("split", n); pre.push(p.h); p = p.t; }
    return T(list(pre), p);
  },
  "lists/splitwith/2": (f, l) => {
    const pre = []; let p = l;
    while (p instanceof Cons && R.truthy(A.invoke(f, p.h))) { pre.push(p.h); p = p.t; }
    return T(list(pre), p);
  },
  "lists/sublist/2": (l, n) => { const a = []; for (let p = l; p instanceof Cons && a.length < n; p = p.t) a.push(p.h); return list(a); },
  "lists/sublist/3": (l, start, n) => list(arr(l).slice(start - 1, start - 1 + n)),
  "lists/sort/1": (l) => list(arr(l).sort(R.termCompare)),
  "lists/nth/2": (n, l) => arr(l)[n - 1],

  // maps
  "maps/new/0": () => R.EMPTY_MAP,
  "maps/put/3": (k, v, m) => m.assoc(k, v),
  "maps/is_key/2": (k, m) => m.has(k),
  "maps/from_list/1": (l) => { let m = R.EMPTY_MAP; for (const p of arr(l)) m = m.assoc(p.items[0], p.items[1]); return m; },
  "maps/to_list/1": (m) => list([...m.entries()].map(([k, v]) => T(k, v))),
  "maps/merge/2": (a, b) => { let m = a; for (const [k, v] of b.entries()) m = m.assoc(k, v); return m; },
  "maps/values/1": (m) => list([...m.entries()].map(([, v]) => v)),
  "maps/keys/1": (m) => list([...m.entries()].map(([k]) => k)),
  "maps/size/1": (m) => m.cnt,
  "maps/remove/2": (k, m) => m.dissoc(k),

  // string (Erlang's, over charlists)
  "string/chr/2": (cs, cp) => { const i = arr(cs).indexOf(cp); return i < 0 ? 0 : i + 1; },
  "string/to_integer/1": toInteger,
  "string/to_float/1": toFloat,
  "string/cspan/2": (cs, delims) => {
    // the length of the prefix of `cs` containing no char of `delims` — a
    // walk that stops at the first delimiter, not a copy of the whole list
    const d = new Set(arr(delims)); let i = 0;
    for (let p = cs; p instanceof Cons && !d.has(p.h); p = p.t) i++;
    return i;
  },

  // unicode
  "unicode/characters_to_list/1": (s) => (typeof s === "string" ? stringToCps(s) : stringToCps(cpsToString(s))),
  "unicode/characters_to_binary/1": (cs) => cpsToString(cs),

  // Beam Lisp host modules the reader reaches
  // the atom-table guard: JS has no atom table to exhaust, so accounting is a no-op
  "Elixir.BeamLisp.AtomGuard/account!/1": () => OK,
  "Elixir.BeamLisp.AtomGuard/reset/0": () => OK,
  "Elixir.BeamLisp.AtomGuard/check!/1": () => OK,
  "Elixir.BeamLisp.AtomGuard/to_atom/1": (s) => R.kw(s),
  "Elixir.BeamLisp.Decimal/unscaled/1": (d) => (d.u >= BigInt(Number.MIN_SAFE_INTEGER) && d.u <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(d.u) : d.u),
  "Elixir.BeamLisp.Decimal/scale/1": (d) => d.s,
  "Elixir.BeamLisp.Decimal/parse/1": (s) => { const d = R.parseDec(s); return d === null ? ERROR : T(OK, d); },
  "Elixir.BeamLisp.Vector/to_list/1": (v) => v.toList(),
  "Elixir.BeamLisp.Vector/new/1": (l) => R.vecFromArray(A.toArray(l)),
  "Elixir.BeamLisp.Set/to_list/1": (s) => list(s.elements().sort(R.compare)),
  // core/to-list: any BL collection (or nil) as a plain list
  "Elixir.BeamLisp.Ns.Core/to-list/1": (c) => (c === null || c === undefined ? EMPTY : isList(c) ? c : list(A.toArray(c))),
  // the data-reader registry (`#tag form`): tag name → {:symbol name}
  "Elixir.BeamLisp.Ns.Rt/data_reader/1": (tag) => (DATA_READERS.has(tag) ? T(OK, DATA_READERS.get(tag)) : ERROR),
};

// ─── the compiler's leaves (priv/boot/compiler.bl, anf.bl, diag.bl) ───────────

/** BeamLisp.Ns.<Camelized> for a namespace — Emit.module_for's rule (each
    dot-segment camelized: `reader-node` → `Reader-node`, `a.b_c` → `A.BC`). */
export function moduleFor(ns) {
  const camel = (seg) => seg.split("_").map((p) => (p ? p[0].toUpperCase() + p.slice(1) : "")).join("");
  return R.kw("Elixir.BeamLisp.Ns." + ns.split(".").map(camel).join("."));
}
// the eager collection ops the compiler runs over finite data (CompilerData)
const eagerList = (x) => (x === null || x === undefined ? [] : A.toArray(x));
const PDICT = new Map();
const nextGensym = (() => { let n = 0; return () => ++n; })();
const UNDEFINED = R.kw("undefined");
const pkey = (k) => R.printStr(k);

// Enum predicates consume one Enumerable cell at a time: all?/empty? must
// not realize a deferred tail just to answer about the prefix.
function* enumerable(c) {
  if (c === null || c === undefined || typeof c === "string") {
    const error = new BLError("Enumerable protocol is not implemented for " + R.printStr(c));
    error.blType = R.kw("Elixir.Protocol.UndefinedError");
    throw error;
  }
  for (let p = cell(c); p !== null; p = cell(p.t)) {
    if (!(p instanceof Cons)) return badarg("Enumerable", c);
    yield p.h;
  }
}

// These are passive CompilerData shape views (host/compiler_data.bl), over
// this host's values. They grant no Source execution or native admission.
const field = (m, k) => m instanceof HMap ? m.get(R.kw(k), null) : null;
const integer = (x) => typeof x === "bigint" || Number.isSafeInteger(x);
const byteSize = (s) => new TextEncoder().encode(s).length;
function bindingReference(value) {
  const digest = (x) => typeof x === "string" && x.length <= 32 && byteSize(x) === 32;
  const phase = field(value, "phase"), space = field(value, "space");
  return value instanceof HMap && value.cnt === 7 &&
    R.keyEq(field(value, "version"), 1) && field(value, "kind") === R.kw("binding-reference") &&
    ["world", "declaration", "id"].every(k => digest(field(value, k))) &&
    integer(phase) && phase >= -4096 && phase <= 4096 &&
    space instanceof Tup && space.items.length === 2 && space.items[0] === R.kw("symbol") &&
    typeof space.items[1] === "string" && space.items[1].length >= 1 && space.items[1].length <= 512 && byteSize(space.items[1]) <= 512;
}
function simpleFunctionClause(node) {
  if (field(node, "op") !== R.kw("fn")) return null;
  const clauses = field(node, "clauses");
  if (!(clauses instanceof Cons) || clauses.t !== EMPTY) return null;
  const clause = clauses.h;
  if (!(clause instanceof HMap) || field(clause, "guard") !== null || !clause.has(R.kw("body"))) return null;
  let pats = field(clause, "pats"), remaining = 255;
  while (pats !== EMPTY) {
    if (--remaining < 0 || !(pats instanceof Cons) || field(pats.h, "pop") !== R.kw("pvar") ||
        typeof field(pats.h, "name") !== "string") return null;
    pats = pats.t;
  }
  return clause;
}

// CompilerData's raw guards run during live macro expansion and namespace
// declaration. Inspect this host's storage directly: never realize a lazy
// value, call a collection protocol, or trust a user-supplied struct tag.
function dataRefuse(reason) {
  throw new BLError("Expected bounded first-order data",
    R.hashMap(R.kw("kind"), R.kw("unsafe-first-order-data"), R.kw("reason"), R.kw(reason)));
}
function ownData(value, key, reason) {
  const descriptor = Object.getOwnPropertyDescriptor(value, key);
  if (!descriptor || !("value" in descriptor)) dataRefuse(reason);
  return descriptor.value;
}
function rawEntries(value, maximum) {
  if (value instanceof HMap && ownData(value, "cnt", "map-storage") > maximum) dataRefuse("node-limit");
  try { return R.rawMapEntries(value, maximum); }
  catch { return dataRefuse("map-storage"); }
}
function rawField(entries, key, fallback = null) {
  const entry = entries.find(([k]) => k === R.kw(key));
  return entry ? entry[1] : fallback;
}
function numberBytes(value) {
  if (value instanceof R.Flt) return 10; // version, NEW_FLOAT_EXT tag, eight payload bytes
  const n = typeof value === "bigint" ? value : BigInt(value);
  if (n >= 0n && n <= 255n) return 3;
  if (n >= -2147483648n && n <= 2147483647n) return 6;
  const magnitude = n < 0n ? -n : n;
  const digits = Math.ceil(magnitude.toString(2).length / 8);
  return digits + (digits < 256 ? 4 : 7);
}
function scalarBytes(value) {
  if (typeof value === "string") return byteSize(value);
  if (value instanceof Kw) {
    const name = ownData(value, "fq", "opaque-value");
    if (typeof name !== "string") dataRefuse("opaque-value");
    return byteSize(name);
  }
  if (value === null) return 3;
  if (typeof value === "boolean") return value ? 4 : 5;
  if (value instanceof R.Flt && !Number.isFinite(ownData(value, "v", "opaque-value"))) dataRefuse("opaque-value");
  if (integer(value) || value instanceof R.Flt) return numberBytes(value);
  return 0;
}
const scalarData = (value) => value === null || typeof value === "boolean" ||
  typeof value === "string" || integer(value) || value instanceof Kw || value instanceof R.Flt;

function rawSymbol(value) {
  if (!(value instanceof Tup)) return false;
  const items = ownData(value, "items", "native-tuple");
  return Array.isArray(items) && items.length === 2 && ownData(items, 0, "native-tuple") === R.kw("symbol") &&
    typeof ownData(items, 1, "native-tuple") === "string";
}
function checkFirstOrder(value, options) {
  if (!(options instanceof HMap)) dataRefuse("invalid-limits");
  const settings = rawEntries(options, 1000000);
  if (settings.some(([k]) => k === R.kw("__struct__"))) dataRefuse("invalid-limits");
  const maxNodes = rawField(settings, "max-nodes", 16384), maxBytes = rawField(settings, "max-bytes", 1048576),
    maxDepth = rawField(settings, "max-depth", 64);
  if (!integer(maxNodes) || maxNodes < 1 || maxNodes > 1000000 ||
      !integer(maxBytes) || maxBytes < 1 || maxBytes > 67108864 ||
      !integer(maxDepth) || maxDepth < 1 || maxDepth > 128) dataRefuse("invalid-limits");
  let nodes = Number(maxNodes), bytes = Number(maxBytes);
  const spend = (depth, amount = 0) => {
    if (depth > maxDepth) dataRefuse("depth-limit");
    if (--nodes < 0) dataRefuse("node-limit");
    if ((bytes -= amount) < 0) dataRefuse("byte-limit");
  };
  const dense = (items, count, depth) => {
    if (!Array.isArray(items) || items.length !== count || count > 32) dataRefuse("vector-storage");
    for (let i = 0; i < count; i++) walk(ownData(items, i, "vector-storage"), depth + 1);
  };
  const trie = (node, level, expected, depth) => {
    spend(depth);
    if (!Array.isArray(node)) dataRefuse("vector-trie");
    if (level === 0) { if (expected !== 32) dataRefuse("vector-count"); dense(node, 32, depth); return; }
    const capacity = 2 ** level, children = Math.ceil(expected / capacity);
    if (node.length !== children || children > 32) dataRefuse("vector-placement");
    for (let i = 0, left = expected; i < 32; i++) {
      const amount = Math.min(left, capacity);
      if (amount === 0) spend(depth + 1); // native vectors carry explicit nil lanes
      else { trie(ownData(node, i, "vector-trie"), level - 5, amount, depth + 1); left -= amount; }
    }
  };
  const walk = (v, depth) => {
    spend(depth, scalarBytes(v));
    if (scalarData(v)) return;
    if (v === EMPTY || v instanceof Cons) {
      for (let remaining = v; remaining !== EMPTY;) {
        if (!(remaining instanceof Cons)) dataRefuse("improper-list");
        walk(ownData(remaining, "h", "improper-list"), depth + 1);
        remaining = ownData(remaining, "t", "improper-list");
      }
    } else if (v instanceof Tup) {
      const items = ownData(v, "items", "native-tuple");
      if (!Array.isArray(items)) dataRefuse("native-tuple");
      if (rawSymbol(v)) walk(ownData(items, 1, "native-tuple"), depth + 1);
      else if (items.length === 3 && ownData(items, 0, "native-tuple") === R.kw("meta")) {
        const form = ownData(items, 1, "native-tuple"), metadata = ownData(items, 2, "native-tuple");
        if (!(rawSymbol(form) || form === EMPTY || form instanceof Cons || form instanceof HMap || form instanceof R.Vec || form instanceof R.HSet || form instanceof R.Dec) ||
            !(metadata instanceof HMap) || rawEntries(metadata, nodes).some(([k]) => k === R.kw("__struct__"))) dataRefuse("native-tuple");
        walk(form, depth + 1); walk(metadata, depth + 1);
      } else dataRefuse("native-tuple");
    } else if (v instanceof Vec) {
      walk(ownData(v, "meta", "vector-fields"), depth + 1);
      const count = ownData(v, "cnt", "vector-storage"), shift = ownData(v, "shift", "vector-trie"),
        root = ownData(v, "root", "vector-trie"), tail = ownData(v, "tail", "vector-storage");
      if (!Number.isSafeInteger(count) || count < 0 || !Array.isArray(tail)) dataRefuse("vector-storage");
      if (count <= 32) {
        if (shift !== 5 || !Array.isArray(root) || root.length !== 0) dataRefuse("vector-storage");
        dense(tail, count, depth);
      } else {
        if (count > maxNodes) dataRefuse("node-limit");
        if (!Number.isInteger(shift) || shift < 5 || shift > 30 || shift % 5 || tail.length < 1 || tail.length > 32) dataRefuse("vector-trie");
        const treeCount = count - tail.length;
        if (treeCount % 32 || tail.length !== 1 + (count - 1) % 32 || (shift !== 5 && treeCount <= 2 ** shift)) dataRefuse("vector-count");
        trie(root, shift, treeCount, depth + 1); dense(tail, tail.length, depth + 1);
      }
    } else if (v instanceof R.HSet) {
      const members = ownData(v, "m", "set-storage");
      if (!(members instanceof HMap)) dataRefuse("set-storage");
      spend(depth + 1);
      for (const [key, marker] of rawEntries(members, nodes)) {
        if (marker !== true) dataRefuse("set-storage");
        walk(key, depth + 2); walk(EMPTY, depth + 2);
      }
    } else if (v instanceof R.Dec) {
      const unscaled = ownData(v, "u", "decimal-storage"), scale = ownData(v, "s", "decimal-storage");
      if (!integer(unscaled) || !integer(scale) || scale < 0) dataRefuse("decimal-storage");
      walk(unscaled, depth + 1); walk(scale, depth + 1);
    } else if (v instanceof HMap) {
      const entries = rawEntries(v, nodes);
      if (entries.some(([k]) => k === R.kw("__struct__"))) dataRefuse("foreign-struct");
      for (const [key, item] of entries) { walk(key, depth + 1); walk(item, depth + 1); }
    } else if (v instanceof LazySeq || v instanceof Delay || v instanceof SeqCursor || v instanceof R.Atom) dataRefuse("foreign-struct");
    else dataRefuse("opaque-value");
  };
  walk(value, 0);
  return value;
}

function rawError(kind, reason) {
  const data = reason === undefined ? R.kw(kind) : T(R.kw(kind), R.kw(reason));
  throw Object.assign(new BLError(kind + (reason === undefined ? "" : ": " + reason)), {data});
}
function checkReaderData(form) {
  const pending = [[form, 0]];
  let nodes = 16384, bytes = 1048576;
  try {
    while (pending.length) {
      const [value, depth] = pending.pop();
      if (--nodes < 0 || (bytes -= 8 + (typeof value === "string" ? byteSize(value) : 0)) < 0 || depth > 64) rawError("invalid_reader_data");
      if (value instanceof R.Flt && !Number.isFinite(ownData(value, "v", "opaque-value"))) rawError("invalid_reader_data");
      if (scalarData(value) || value === EMPTY) continue;
      if (value instanceof Cons) {
        pending.push([ownData(value, "t", "improper-list"), depth], [ownData(value, "h", "improper-list"), depth + 1]);
      } else if (value instanceof Tup) {
        const items = ownData(value, "items", "native-tuple");
        if (!Array.isArray(items) || items.length > nodes) rawError("invalid_reader_data");
        for (let i = items.length - 1; i >= 0; i--) pending.push([ownData(items, i, "native-tuple"), depth + 1]);
      } else if (value instanceof HMap) {
        const entries = rawEntries(value, nodes);
        if (entries.some(([k]) => k === R.kw("__struct__"))) rawError("invalid_reader_data");
        for (const [key, item] of entries) pending.push([item, depth + 1], [key, depth + 1]);
      } else if (value instanceof R.Dec) {
        const unscaled = ownData(value, "u", "decimal-storage"), scale = ownData(value, "s", "decimal-storage");
        if (!integer(unscaled) || !integer(scale) || scale < 0) rawError("invalid_reader_data");
        // The native Reader delegates decimal fields to the first-order raw
        // walker: numeric ETF byte costs, without Reader's eight-byte overhead.
        for (const part of [unscaled, scale]) {
          if (--nodes < 0 || (bytes -= numberBytes(part)) < 0 || depth + 1 > 64) rawError("invalid_reader_data");
        }
      } else rawError("invalid_reader_data");
    }
  } catch { rawError("invalid_reader_data"); }
  return form;
}
const unmetaReader = (node) => node instanceof Tup && node.items.length === 3 && node.items[0] === R.kw("meta") ? unmetaReader(node.items[1]) : node;
const readerTag = (node, tag) => node instanceof Tup && node.items.length === 2 && node.items[0] === R.kw(tag);
function requireName(node) {
  node = unmetaReader(node);
  if (!readerTag(node, "symbol") || typeof node.items[1] !== "string" || !byteSize(node.items[1])) rawError("invalid_namespace_require", "symbol");
  return node.items[1];
}
function namespaceRequire(spec) {
  checkReaderData(spec);
  const node = unmetaReader(spec);
  if (readerTag(node, "symbol")) return T(requireName(node), null, EMPTY);
  if (!readerTag(node, "vector") || !isList(node.items[1]) || node.items[1] === EMPTY) rawError("invalid_namespace_require", "shape");
  const items = arr(node.items[1]), target = requireName(items[0]), seen = new Set();
  let alias = null, refers = EMPTY;
  for (let i = 1; i < items.length; i += 2) {
    if (i + 1 === items.length) rawError("invalid_namespace_require", "missing-option-value");
    const key = unmetaReader(items[i]), value = unmetaReader(items[i + 1]);
    if (!readerTag(key, "keyword") || !["as", "refer"].includes(key.items[1])) rawError("invalid_namespace_require", "option");
    const option = key.items[1];
    if (seen.has(option)) rawError("invalid_namespace_require", "duplicate-option");
    seen.add(option);
    if (option === "as") alias = requireName(value);
    else if (readerTag(value, "keyword") && value.items[1] === "all") refers = R.kw("all");
    else {
      if (!readerTag(value, "vector") || !isList(value.items[1])) rawError("invalid_namespace_require", "refer");
      const names = arr(value.items[1]).map(requireName);
      if (new Set(names).size !== names.length) rawError("invalid_namespace_require", "duplicate-refer");
      refers = list(names);
    }
  }
  return T(target, alias, refers);
}
function namespaceExcludes(specs) {
  checkReaderData(specs);
  if (!isList(specs)) rawError("invalid_namespace_excludes", "shape");
  const items = arr(specs), out = [];
  for (let i = 0; i < items.length; i += 2) {
    if (i + 1 === items.length) rawError("invalid_namespace_excludes", "missing-value");
    const key = unmetaReader(items[i]), value = unmetaReader(items[i + 1]);
    if (!readerTag(key, "keyword") || key.items[1] !== "exclude" || !readerTag(value, "vector") || !isList(value.items[1])) rawError("invalid_namespace_excludes", "option");
    out.push(...arr(value.items[1]).map(requireName));
  }
  return list(out);
}
function namespaceClauses(forms) {
  checkReaderData(forms);
  if (!isList(forms)) rawError("invalid_namespace_header", "clauses");
  const clauses = forms instanceof Cons && typeof unmetaReader(forms.h) === "string" ? forms.t : forms;
  for (const clause of arr(clauses)) {
    const node = unmetaReader(clause);
    if (!readerTag(node, "list") || !isList(node.items[1]) || node.items[1] === EMPTY) rawError("invalid_namespace_header", "clause");
    const head = unmetaReader(node.items[1].h);
    if (!readerTag(head, "keyword") || !["require", "import", "refer-clojure"].includes(head.items[1])) rawError("invalid_namespace_header", "clause");
  }
  return clauses;
}
Object.assign(LEAVES, {
  "Elixir.BeamLisp.CompilerData/check_first_order!/1": (v) => checkFirstOrder(v, R.EMPTY_MAP),
  "Elixir.BeamLisp.CompilerData/check_first_order!/2": checkFirstOrder,
  "Elixir.BeamLisp.CompilerData/check_reader_data!/1": checkReaderData,
  "Elixir.BeamLisp.CompilerData/namespace_require_spec/1": namespaceRequire,
  "Elixir.BeamLisp.CompilerData/namespace_core_excludes/1": namespaceExcludes,
  "Elixir.BeamLisp.CompilerData/namespace_clauses/1": namespaceClauses,
  "Elixir.BeamLisp.CompilerData/binding_reference?/1": bindingReference,
  "Elixir.BeamLisp.CompilerData/simple_function_clause/1": simpleFunctionClause,
  "Elixir.BeamLisp.CompilerData/catch_stack_bindings/0": () => R.hashMap(R.kw("frames"), "__STACKTRACE__", R.kw("raw"), "__STACKTRACE_RAW__"),
  "Elixir.BeamLisp.CompilerData/eager_to_list/1": (c) => list(eagerList(c)),
  // Elixir Enumerable callback convention: element first, accumulator last.
  "Elixir.Enum/all?/2": (c, f) => { for (const x of enumerable(c)) if (!R.truthy(A.invoke(f, x))) return false; return true; },
  "Elixir.Enum/each/2": (c, f) => { for (const x of enumerable(c)) A.invoke(f, x); return OK; },
  "Elixir.Enum/empty?/1": (c) => enumerable(c).next().done,
  "Elixir.Enum/group_by/2": (c, f) => {
    let groups = R.EMPTY_MAP;
    for (const x of enumerable(c)) { const k = A.invoke(f, x); groups = groups.assoc(k, new Cons(x, groups.get(k, EMPTY))); }
    let out = R.EMPTY_MAP;
    for (const [k, xs] of groups) out = out.assoc(k, R.reverseI(xs));
    return out;
  },
  "Elixir.Enum/map/2": (c, f) => list(eagerList(c).map((x) => A.invoke(f, x))),
  "Elixir.Enum/filter/2": (c, f) => {
    const out = [];
    for (const x of enumerable(c)) if (R.truthy(A.invoke(f, x))) out.push(x);
    return list(out);
  },
  "Elixir.Enum/map_reduce/3": (c, acc, f) => {
    const out = [];
    for (const x of enumerable(c)) {
      const pair = A.invoke(f, x, acc);
      if (!(pair instanceof Tup) || pair.items.length !== 2) return badarg("map_reduce result", pair);
      out.push(pair.items[0]); acc = pair.items[1];
    }
    return T(list(out), acc);
  },
  "Elixir.Enum/reverse/1": (c) => list(Array.from(enumerable(c)).reverse()),
  "Elixir.Enum/sort_by/2": (c, f) => {
    const keyed = [];
    for (const value of enumerable(c)) keyed.push([A.invoke(f, value), value]);
    return list(keyed.sort((a, b) => R.termCompare(a[0], b[0])).map(([, value]) => value));
  },
  "Elixir.Enum/with_index/1": (c) => list(Array.from(enumerable(c)).map((x, i) => T(x, i))),
  "Elixir.Enum/flat_map/2": (c, f) => list(eagerList(c).flatMap((x) => eagerList(A.invoke(f, x)))),
  "Elixir.Enum/reduce/3": (c, acc, f) => eagerList(c).reduce((a, x) => A.invoke(f, x, a), acc),
  "Elixir.Enum/sort/1": (c) => list(eagerList(c).sort(R.compare)),
  "Elixir.Enum/uniq/1": (c) => { const out = []; let seen = R.EMPTY_SET; for (const x of eagerList(c)) if (!seen.has(x)) { seen = seen.conj(x); out.push(x); } return list(out); },
  "Elixir.Enum/zip/2": (a, b) => { const xs = eagerList(a), ys = eagerList(b); return list(xs.slice(0, ys.length).map((x, i) => T(x, ys[i]))); },
  "Elixir.Enum/drop/2": (c, n) => { const xs = eagerList(c); return list(n < 0 ? xs.slice(0, Math.max(0, xs.length + n)) : xs.slice(n)); },
  "Elixir.Map/get/2": (m, k) => m.get(k, null),
  "Elixir.Map/new/1": (c) => {
    let out = R.EMPTY_MAP;
    for (const pair of enumerable(c)) {
      if (!(pair instanceof Tup) || pair.items.length !== 2) return badarg("Map.new entry", pair);
      out = out.assoc(pair.items[0], pair.items[1]);
    }
    return out;
  },
  "Elixir.Atom/to_string/1": (a) => a === null ? "nil" : typeof a === "boolean" ? String(a) : a instanceof Kw ? a.fq : badarg("atom", a),
  "Elixir.Map/to_list/1": (m) => list(m.entries().map(([k, v]) => T(k, v))),
  "lists/seq/2": (a, b) => { if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || b < a - 1) return badarg("seq", T(a, b)); return list(Array.from({length: Math.max(0, b - a + 1)}, (_, i) => a + i)); },
  "lists/all/2": (f, xs) => { for (const x of arr(xs)) { const v = A.invoke(f, x); if (v === false) return false; if (v !== true) return badarg("all predicate", v); } return true; },
  "Elixir.BeamLisp.CompilerData/eager_map/2": (f, c) => list(eagerList(c).map((x) => A.invoke(f, x))),
  "Elixir.BeamLisp.CompilerData/eager_map/3": (f, a, b) => { const xs = eagerList(a), ys = eagerList(b), n = Math.min(xs.length, ys.length); const o = []; for (let i = 0; i < n; i++) o.push(A.invoke(f, xs[i], ys[i])); return list(o); },
  "Elixir.BeamLisp.CompilerData/eager_filter/2": (f, c) => list(eagerList(c).filter((x) => R.truthy(A.invoke(f, x)))),
  "Elixir.BeamLisp.CompilerData/eager_concat/1": (cs) => list(eagerList(cs).flatMap(eagerList)),
  "Elixir.BeamLisp.CompilerData/eager_mapcat/2": (f, c) => list(eagerList(c).flatMap((x) => eagerList(A.invoke(f, x)))),
  "Elixir.BeamLisp.CompilerData/eager_map_indexed/2": (f, c) => list(eagerList(c).map((x, i) => A.invoke(f, i, x))),
  "Elixir.BeamLisp.CompilerData/eager_distinct/1": (c) => { const out = []; let seen = R.EMPTY_SET; for (const x of eagerList(c)) if (!seen.has(x)) { seen = seen.conj(x); out.push(x); } return list(out); },

  // the process dictionary: one JS realm is one "process"
  // erlang:get/put answer the atom `undefined` for a missing key, not nil
  "erlang/get/1": (k) => (PDICT.has(pkey(k)) ? PDICT.get(pkey(k)) : UNDEFINED),
  "erlang/put/2": (k, v) => { const old = PDICT.has(pkey(k)) ? PDICT.get(pkey(k)) : UNDEFINED; PDICT.set(pkey(k), v); return old; },
  "erlang/erase/1": (k) => { const key = pkey(k), old = PDICT.has(key) ? PDICT.get(key) : UNDEFINED; PDICT.delete(key); return old; },
  "Elixir.Process/get/1": (k) => (PDICT.has(pkey(k)) ? PDICT.get(pkey(k)) : null),
  "Elixir.Process/get/2": (k, d) => (PDICT.has(pkey(k)) ? PDICT.get(pkey(k)) : d),
  "Elixir.Process/put/2": (k, v) => { const old = PDICT.has(pkey(k)) ? PDICT.get(pkey(k)) : null; PDICT.set(pkey(k), v); return old; },
  "Elixir.System/unique_integer/1": (() => { let n = 0; return () => ++n; })(),

  "erlang/function_exported/3": () => false,
  "erlang/is_float/1": (x) => x instanceof R.Flt,
  // `float_to_binary(f, [:short])`: the shortest round-tripping digits, always
  // with a `.` (0.1, 100.0, 1.0e21) — JS's shortest digits, Erlang's spelling
  "erlang/float_to_binary/2": (f) => {
    const v = f instanceof R.Flt ? f.v : f;
    let s = String(v);
    if (/e/.test(s)) { let [m, e] = s.split("e"); if (!m.includes(".")) m += ".0"; return m + "e" + (e.startsWith("+") ? e.slice(1) : e); }
    return s.includes(".") || !Number.isFinite(v) ? s : s + ".0";
  },
  "Elixir.Integer/to_string/2": (n, base) => n.toString(base).toUpperCase(),
  "erlang/is_number/1": (x) => R.isNumber(x),
  "erlang/is_bitstring/1": (x) => typeof x === "string",
  "lists/sort/2": (f, l) => list(arr(l).sort((a, b) => (R.truthy(A.invoke(f, a, b)) ? -1 : 1))),
  "maps/filter/2": (f, m) => { let o = R.EMPTY_MAP; for (const [k, v] of m.entries()) if (R.truthy(A.invoke(f, k, v))) o = o.assoc(k, v); return o; },
  "maps/without/2": (ks, m) => { let o = m; for (const k of arr(ks)) o = o.dissoc(k); return o; },
  "maps/with/2": (ks, m) => {
    if (!(m instanceof HMap)) return badarg("with map", m);
    let out = R.EMPTY_MAP;
    for (let p = ks; p !== EMPTY; p = p.t) {
      if (!(p instanceof Cons)) return badarg("with keys", ks);
      if (m.has(p.h)) out = out.assoc(p.h, m.get(p.h));
    }
    return out;
  },

  "Elixir.BeamLisp.Link/module_for/1": moduleFor,
  // a JS compile never loads beams: there is nothing for settle to rebuild
  "Elixir.BeamLisp.Link/settle/0": () => OK,
  "Elixir.BeamLisp.Tiers/boot_namespaces/0": () => list(["anf", "compiler", "core", "diag", "lower", "optimize", "reader", "reader-node", "rt", "sugar"]),
  "Elixir.BeamLisp.Record/record_module?/1": () => false,
  "Elixir.BeamLisp.Record/deftype_module?/1": () => false,
  // metadata on values (core's meta/with-meta/vary-meta are these on BEAM)
  "Elixir.BeamLisp.FormMeta/meta/1": A.meta,
  "Elixir.BeamLisp.FormMeta/with_meta/2": A.with_meta,
  "Elixir.BeamLisp.FormMeta/vary_meta/2": A.vary_meta,

  // defserver codegen tables (priv/host/server.bl, verbatim)
  "Elixir.BeamLisp.Server/callback/1": (n) => ({ "init": T(R.kw("init"), 1, R.kw("vector")), "handle-call": T(R.kw("handle_call"), 3, R.kw("pattern")), "handle-cast": T(R.kw("handle_cast"), 2, R.kw("pattern")), "handle-info": T(R.kw("handle_info"), 2, R.kw("pattern")), "handle-continue": T(R.kw("handle_continue"), 2, R.kw("vector")), "terminate": T(R.kw("terminate"), 2, R.kw("vector")) }[n] ?? null),
  "Elixir.BeamLisp.Server/callback_order/0": () => list(["init", "handle_call", "handle_cast", "handle_info", "handle_continue", "terminate", "code_change"].map(R.kw)),

  // the loader, in a page: every namespace the page has is already loaded
  // (built in), so probes answer from the registry and loads are no-ops
  "Elixir.BeamLisp.Loader/declare_require/3": () => OK,
  "Elixir.BeamLisp.Loader/ensure_loaded/1": () => OK,
  // the readiness guard the compiler puts before a direct call into another
  // namespace (when that namespace was already loaded at compile time)
  "Elixir.BeamLisp.Loader/ensure_ready/1": () => OK,
  "Elixir.BeamLisp.Loader/load_provider/1": () => OK,
  "Elixir.BeamLisp.Loader/maybe_load_macro/2": () => null,
  "Elixir.BeamLisp.Loader/resolvable?/1": (ns) => ENV["ns_exists?"](ns),
  "Elixir.BeamLisp.Loader/source_decl/2": () => null,

  // core/rt functions the compiler reaches by MODULE name (not linked as core
  // globals): their BL definitions, on the JS value model
  "Elixir.BeamLisp.Ns.Core/tuple__bl_v/1": (xs) => new Tup(arr(xs)),
  "Elixir.BeamLisp.Ns.Core/run!/2": (f, coll) => { for (const x of A.toArray(coll)) A.invoke(f, x); return null; },
  "Elixir.BeamLisp.Ns.Rt/call_shape_error/2": (v, arity) => "cannot call " + R.printStr(v) + " with " + arity + " argument" + (arity === 1 ? "" : "s") + " — it is not a function",
  "Elixir.BeamLisp.Server/module_for/2": (ns, name) => {
    const camel = (seg) => seg.split(/[-_]/).map((p) => (p ? p[0].toUpperCase() + p.slice(1) : "")).join("");
    return R.kw("Elixir.BeamLisp.Server." + (ns + "." + name).split(".").map(camel).join("."));
  },
  // Generated from the actual native Server vocabulary by this build.
  "Elixir.BeamLisp.Server/return_constructor_shapes/0": () => {
    if (RETURN_CONSTRUCTOR_SHAPES === null) throw new BLError("missing generated Server return vocabulary");
    return RETURN_CONSTRUCTOR_SHAPES;
  },
  "Elixir.BeamLisp.Server/return_constructors/0": () => R.EMPTY_MAP,
  // `~@`: a vector or list spreads, nil is empty, a map yields its entries
  // as {k, v} tuples (rt/k-splice) — the tail is shared
  "Elixir.BeamLisp.Ns.Rt/splice/2": (spliced, tail) => {
    const xs = spliced === null || spliced === undefined ? [] : spliced instanceof HMap ? spliced.entries().map(([k, v]) => T(k, v)) : A.toArray(spliced);
    let r = tail === null || tail === undefined ? EMPTY : tail;
    for (let i = xs.length - 1; i >= 0; i--) r = new Cons(xs[i], r);
    return r;
  },
  // a fresh symbol DATUM in the `base__N__auto` shape (rt/print-gensym)
  "Elixir.BeamLisp.Ns.Rt/gensym/0": () => T(R.kw("symbol"), "G__" + nextGensym() + "__auto"),
  "Elixir.BeamLisp.Ns.Rt/gensym/1": (p) => T(R.kw("symbol"), (p instanceof Kw ? p.fq : String(p)) + "__" + nextGensym() + "__auto"),
  "Elixir.BeamLisp.Env/op_of/2": (mod, fun) => null,
  "Elixir.BeamLisp.Env/caps_allowed?/2": (mod, op) => true,

  // errors
  "Elixir.BeamLisp.CompileError/exception/1": (opts) => { const e = new BLError(kwGet(opts, "message") ?? "compile error"); e.blData = opts; return e; },
  "Elixir.RuntimeError/exception/1": (msg) => new BLError(typeof msg === "string" ? msg : R.printStr(msg)),
});
/** `[{:message m} …]` keyword-list option lookup. */
function kwGet(opts, k) {
  if (opts instanceof HMap) return opts.get(R.kw(k), null);
  for (const p of arr(opts)) if (p instanceof Tup && p.items[0] === R.kw(k)) return p.items[1];
  return null;
}

// ─── js/run: evaluate emitted JS in this realm (priv/lib/js/eval.bl) ─────────
//
// The text is a function body from js.emit with run-time linking: `G(ns,
// name)` reads the live registry, then an uninterned compiled definition;
// `X("mod/fun/arity")` a compiled namespace's export or a leaf. `R`/`A` are the
// value runtime and the host ABI.
const MACRO = R.kw("$macro");

/** `d_<mangle name>` of the compiled namespace `ns`, or undefined. A compiled
    `defn` is not interned as a var, so this is how an uninterned definition
    (core/sugar, or a name nothing rebound) is reached. */
function moduleDef(ns, name) {
  const ex = NAMESPACES.get(ns);
  return ex === undefined ? undefined : ex["d_" + mangle(name)];
}
/** The compiled export a global `ns/name` names, in `ENV.fetch!`'s candidate
    order (the name, where it was referred from, `core`, `sugar`). */
function compiledGlobal(ns, name) {
  const slash = name.indexOf("/");
  if (slash > 0) {
    const q = name.slice(0, slash), n = name.slice(slash + 1);
    return moduleDef(ENV.alias_target(ns, q) ?? q, n);
  }
  const src = ENV.refer_source(ns, name);
  const cands = src === null ? [ns, "core", "sugar"] : [ns, src, "core", "sugar"];
  for (const c of cands) { const v = moduleDef(c, name); if (v !== undefined) return v; }
  return undefined;
}
/** `G(ns, name)`: a name's value in `ns`. A LIVE Env binding wins — including
    one bound to nil (a `def` of nil is a real binding) — with aliases/refers
    resolved by `ENV.fetch`. A name no var holds falls back to the compiled
    namespace that defines it. A `{:$macro fn}` value is its fn when called. */
function G(ns, name) {
  const r = ENV.fetch(ns, name);
  let v;
  if (r instanceof Tup) v = r.items[1];
  else {
    v = compiledGlobal(ns, name);
    if (v === undefined) throw new BLError("undefined var: " + ns + "/" + name);
  }
  if (v instanceof Tup && v.items[0] === MACRO) return v.items[1];
  return v;
}
function GX(ns, name) {
  const r = ENV.fetch_exact(ns, name);
  let v;
  if (r instanceof Tup) v = r.items[1];
  else {
    for (const [n, s] of exactCandidates(ns, name)) {
      v = moduleDef(n, s);
      if (v !== undefined) break;
    }
    if (v === undefined) throw new BLError("undefined var: " + ns + "/" + name);
  }
  return v instanceof Tup && v.items[0] === MACRO ? v.items[1] : v;
}
/** `X("mod/fun/arity")`: the compiled namespace function (a `__bl_v` name as
    its `.v`), else the exact leaf — ONE resolution rule, shared with
    host-leaves' `erlang/apply`. No core-table fallback exists. */
function X(lk) { return resolveRemote(lk); }
// seed the registry with BEAM's core links, so the compiler in JS links
// core calls exactly as the BEAM compiler does
for (const [name, info] of LINKS) ENV.put_link("core", name, info);
ENV.declare_ns("core");
/** Run one emitted function body. The emit target imports the host ABI as `A`
    (`A.invokeList`, `A.NOT_FOUND`, `A.K_error`, `A.blfnFn`, `A.toArray`); a
    page installs this as its `js/run` host fn: `globalThis.BL_HOST = { run }`
    before importing js.eval's build. */
export function run(body) { return new Function("R", "A", "G", "GX", "X", "J", "C", body)(R, A, G, GX, X, J, C); }

// ONE table, assembled from its parts with NO silent override: a leaf key
// defined in two places is a load error naming both. (Two files once both
// defined maps.get and Regex.run; the first silently won, so compiled code
// ran a different leaf than the one its author edited.)
function addLeaves(part, entries) {
  for (const [k, f] of entries) {
    if (Object.prototype.hasOwnProperty.call(LEAVES, k)) throw new Error("leaf " + k + " is defined twice (" + LEAF_OWNER.get(k) + " and " + part + ")");
    LEAVES[k] = f; LEAF_OWNER.set(k, part);
  }
}
const LEAF_OWNER = new Map(Object.keys(LEAVES).map((k) => [k, "leaves.mjs"]));
// BeamLisp.LazySeq / SeqCursor / Deferred / LazyMemo.seen
addLeaves("lazy.mjs", Object.entries(LAZY_LEAVES));
// what compiled core.bl/rt.bl reach, incl. the struct-aware map_get/maps.get
addLeaves("host-leaves.mjs", Object.entries(HOST_LEAVES));
// BeamLisp.Env — the namespace/var registry, every function at the arity the
// BL sources call it with
addLeaves("env.mjs", Object.entries(ENV).map(([name, fn]) => ["Elixir.BeamLisp.Env/" + name + "/" + fn.length, fn]));
bindTable(LEAVES);
R.bindApply2(LEAVES["erlang/apply/2"]);

/** `#tag` → reader symbol node, registered with `registerDataReader`. */
const DATA_READERS = new Map();
export function registerDataReader(tag, symName) { DATA_READERS.set(tag, T(R.kw("symbol"), symName)); }

const MISSING = { missing: true };

// ─── the module table: compiled namespaces, by name ─────────────────────────
// Each compiled namespace module registers its exports when it finishes
// loading. A namespace that refers to one LATER in load order (rt → core) holds
// a late-bound view: property reads go to the registered module at CALL time.
const NAMESPACES = new Map();
/** A compiled namespace module registers its exports under its ns name and its
    BEAM module name. `rt` additionally binds the host ABI's runtime seam, so
    the ABI's general operations (`toArray`, `get`, non-fn `invoke`) reach the
    ONE compiled runtime. */
export function registerNamespace(ns, modName, exports) {
  NAMESPACES.set(ns, exports);
  registerModule(modName, exports);
  registerModule(ns, exports);
  ENV.declare_ns(ns);
  if (ns === "rt") A.bindRuntime(exports);
}
export function lateModule(ns) {
  return new Proxy({}, { get(_, k) {
    const m = NAMESPACES.get(ns);
    if (!m) throw new BLError(ns + " is not loaded yet (a call into it during the load of a namespace it depends on)");
    return m[k];
  } });
}

/** The declared leaf names, for the build's linker. */
export const NAMES = Object.keys(LEAVES);
